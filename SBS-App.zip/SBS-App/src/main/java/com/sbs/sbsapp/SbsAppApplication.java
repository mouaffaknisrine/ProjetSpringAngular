package com.sbs.sbsapp;

import com.sbs.sbsapp.dtos.ProjetDTO;
import com.sbs.sbsapp.entities.Collaborateur;
import com.sbs.sbsapp.entities.Projet;
import com.sbs.sbsapp.enums.Practice;
import com.sbs.sbsapp.services.AppService;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import java.util.List;
import java.util.stream.Stream;

@SpringBootApplication
public class SbsAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(SbsAppApplication.class, args);
    }
    //@Bean
    CommandLineRunner commandLineRunner(AppService appService){
        return args ->{
                ProjetDTO prjt=new ProjetDTO();
                prjt.setNom("Reporting BSIC");
                prjt.setTypeActivite("Pret");
                prjt.setPractice(Practice.R_EDITIQUE);
                prjt.setAgence(4523);
                prjt.setChefProjet("Yann");
                appService.saveProjet(prjt);
            };
        }
    }


