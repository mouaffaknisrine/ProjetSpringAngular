package com.sbs.sbsapp.mappers;

import com.fasterxml.jackson.databind.util.BeanUtil;
import com.sbs.sbsapp.dtos.ProjetDTO;
import com.sbs.sbsapp.entities.Projet;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;
//MapStruct est un framework qui fait le mapping
@Service
public class SbsMapperImpl {
    public ProjetDTO fromProjet(Projet projet){
        ProjetDTO projetDTO=new ProjetDTO();
        BeanUtils.copyProperties(projet,projetDTO);
        return projetDTO;
    }
    public Projet fromProjetDTO(ProjetDTO projetDTO){
        Projet projet=new Projet();
        BeanUtils.copyProperties(projetDTO,projet);
        return projet;
    }

}
