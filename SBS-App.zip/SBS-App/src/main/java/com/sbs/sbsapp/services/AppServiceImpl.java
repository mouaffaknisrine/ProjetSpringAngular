package com.sbs.sbsapp.services;

import com.sbs.sbsapp.dtos.ProjetDTO;
import com.sbs.sbsapp.entities.Collaborateur;
import com.sbs.sbsapp.entities.Projet;
import com.sbs.sbsapp.enums.Practice;
import com.sbs.sbsapp.enums.Profil;
import com.sbs.sbsapp.exceptions.CollabNotFoundException;
import com.sbs.sbsapp.exceptions.ProjetNotFoundException;
import com.sbs.sbsapp.mappers.SbsMapperImpl;
import com.sbs.sbsapp.repositories.CollaborateurRepository;
import com.sbs.sbsapp.repositories.ProjetRepository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
@AllArgsConstructor
//pour loger des messages
@Slf4j
public class  AppServiceImpl implements AppService{
    private ProjetRepository projetRepository;
    private CollaborateurRepository collaborateurRepository;
    private SbsMapperImpl sbsMapper;
    @Override
    public ProjetDTO saveProjet(ProjetDTO projetDTO) {
        log.info("Saving new project");
        Projet projet=sbsMapper.fromProjetDTO(projetDTO);
        // Vérifier la valeur de la propriété practice
        String practiceValue = projet.getPractice().getValue(); // Supposons que vous ayez ajouté une méthode getValue() dans l'énumération Practice pour obtenir la valeur textuelle.
        // Générer l'ID en fonction de la valeur de practice
        String generatedId;
        if (Practice.PS_DEV_DIGI.getValue().equals(practiceValue)) {
            // Générer un ID pour la practice "PS_DEV_DIGI" (ex: D1, D2, D3, ...)
            Long idCounter = projetRepository.countByPractice(Practice.PS_DEV_DIGI); // Récupérer le nombre de projets avec la practice "PS_DEV_DIGI" enregistrés en base de données.
            System.out.println(idCounter);
            generatedId = "D" + (idCounter + 1); // ID au format "D" suivi d'un nombre incrémenté.
            System.out.println(generatedId);
        } else if (Practice.R_EDITIQUE.getValue().equals(practiceValue)) {
            // Générer un ID pour la practice "R_EDITIQUE" (ex: R1, R2, R3, ...)
            Long idCounter = projetRepository.countByPractice(Practice.R_EDITIQUE); // Récupérer le nombre de projets avec la practice "R_EDITIQUE" enregistrés en base de données.
            generatedId = "R" + (idCounter + 1); // ID au format "R" suivi d'un nombre incrémenté.
        } else {
            // Générer un ID par défaut si la practice n'est pas reconnue
            generatedId = "DEFAULT" + (projetRepository.count() + 1); // Utilisation d'un ID par défaut suivi d'un nombre incrémenté.
        }
        projet.setId(generatedId); // Définir l'ID généré sur l'objet Projet.
        Projet savedProjet = projetRepository.save(projet);
        return sbsMapper.fromProjet(savedProjet);
    }

    @Override
    public Collaborateur saveCollaborateur(String nom, Profil profil, Practice practice, String projetId) throws ProjetNotFoundException {
        Projet projet=projetRepository.findById(projetId).orElse(null);
        if(projet==null)
            throw new ProjetNotFoundException("Project not found");
        Collaborateur collaborateur = new Collaborateur();
        collaborateur.setNom(nom);
        collaborateur.setPractice(practice);
        collaborateur.setProfil(profil);
        collaborateur.setProjet(projet);
        Collaborateur saveColla=collaborateurRepository.save(collaborateur);
        return saveColla;
    }
    //consulter un projet par id
    @Override
    public ProjetDTO getProjet(String prjtId) throws ProjetNotFoundException {
        Projet projet=projetRepository.findById(prjtId)
                .orElseThrow(()->new ProjetNotFoundException("Projet not found"));
        return sbsMapper.fromProjet(projet);
    }

    @Override
    public List<ProjetDTO> listProjets() {
        List<Projet> projets=projetRepository.findAll();
        List<ProjetDTO> projetDTOS = projets.stream()
                .map(projet -> sbsMapper.fromProjet(projet))
                .collect(Collectors.toList());
        /* List<ProjetDTO> projetDTOS= new ArrayList<>();
        *//*for (Projet projet:projets){
            ProjetDTO projetDTO=sbsMapper.fromProjet(projet);
            projetDTOS.add(projetDTO);
        }*/
        return projetDTOS;
    }
    @Override
    public ProjetDTO updateProjet(ProjetDTO projetDTO) {
        log.info("Saving new project");
        Projet projet=sbsMapper.fromProjetDTO(projetDTO);
        // Vérifier la valeur de la propriété practice
        String practiceValue = projet.getPractice().getValue(); // Supposons que vous ayez ajouté une méthode getValue() dans l'énumération Practice pour obtenir la valeur textuelle.
        // Générer l'ID en fonction de la valeur de practice
        String generatedId;
        if (Practice.PS_DEV_DIGI.getValue().equals(practiceValue)) {
            // Générer un ID pour la practice "PS_DEV_DIGI" (ex: D1, D2, D3, ...)
            Long idCounter = projetRepository.countByPractice(Practice.PS_DEV_DIGI); // Récupérer le nombre de projets avec la practice "PS_DEV_DIGI" enregistrés en base de données.
            System.out.println(idCounter);
            generatedId = "D" + (idCounter + 1); // ID au format "D" suivi d'un nombre incrémenté.
            System.out.println(generatedId);
        } else if (Practice.R_EDITIQUE.getValue().equals(practiceValue)) {
            // Générer un ID pour la practice "R_EDITIQUE" (ex: R1, R2, R3, ...)
            Long idCounter = projetRepository.countByPractice(Practice.R_EDITIQUE); // Récupérer le nombre de projets avec la practice "R_EDITIQUE" enregistrés en base de données.
            generatedId = "R" + (idCounter + 1); // ID au format "R" suivi d'un nombre incrémenté.
        } else {
            // Générer un ID par défaut si la practice n'est pas reconnue
            generatedId = "DEFAULT" + (projetRepository.count() + 1); // Utilisation d'un ID par défaut suivi d'un nombre incrémenté.
        }
        projet.setId(generatedId); // Définir l'ID généré sur l'objet Projet.
        Projet savedProjet = projetRepository.save(projet);
        return sbsMapper.fromProjet(savedProjet);
    }
    @Override
    public void deleteProjet(String projetId){
        projetRepository.deleteById(projetId);
    }

    @Override
    public List<Collaborateur> listCollabs(){
        return collaborateurRepository.findAll();
    }

    @Override
    public Collaborateur getCollaborateur(Long collabId) throws CollabNotFoundException {
        Collaborateur collaborateur=collaborateurRepository.findById(collabId)
                .orElseThrow(()->new CollabNotFoundException("Collaborateur not found"));
        return null;
    }
}
