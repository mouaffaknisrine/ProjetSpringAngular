package com.sbs.sbsapp.enums;

public enum Profil {
    EMPLOYE,STAGIAIRE;
}
