package com.sbs.sbsapp.entities;

import com.sbs.sbsapp.enums.Practice;
import com.sbs.sbsapp.enums.Profil;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
public class Collaborateur {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(length = 30)
    private String nom;
    @Column(length = 30)
    private String prenom;
    @Enumerated(EnumType.STRING)
    private Practice practice;
    @Enumerated(EnumType.STRING)
    private Profil profil;
    @ManyToOne
    private Projet projet;
}
