package com.sbs.sbsapp.repositories;

import com.sbs.sbsapp.entities.Collaborateur;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CollaborateurRepository extends JpaRepository<Collaborateur,Long> {
}
