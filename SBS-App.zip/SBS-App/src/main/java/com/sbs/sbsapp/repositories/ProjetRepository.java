package com.sbs.sbsapp.repositories;

import com.sbs.sbsapp.entities.Projet;
import com.sbs.sbsapp.enums.Practice;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjetRepository extends JpaRepository<Projet,String> {
    Long countByPractice(Practice practice);

}
