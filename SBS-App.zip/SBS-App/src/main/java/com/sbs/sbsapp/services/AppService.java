package com.sbs.sbsapp.services;

import com.sbs.sbsapp.dtos.ProjetDTO;
import com.sbs.sbsapp.entities.Collaborateur;
import com.sbs.sbsapp.entities.Projet;
import com.sbs.sbsapp.enums.Practice;
import com.sbs.sbsapp.enums.Profil;
import com.sbs.sbsapp.exceptions.CollabNotFoundException;
import com.sbs.sbsapp.exceptions.ProjetNotFoundException;

import java.util.List;

public interface AppService {
    ProjetDTO saveProjet(ProjetDTO projetDTO);
    Collaborateur saveCollaborateur(String nom, Profil profil, Practice practice, String  projetId) throws ProjetNotFoundException;

    ProjetDTO getProjet(String projetId) throws ProjetNotFoundException;

    List<ProjetDTO> listProjets();

    ProjetDTO updateProjet(ProjetDTO projetDTO);

    void deleteProjet(String projetId);

    List<Collaborateur> listCollabs();

    Collaborateur getCollaborateur(Long collabId) throws CollabNotFoundException;
}
