package com.sbs.sbsapp.exceptions;

public class CollabNotFoundException extends Exception {
    public CollabNotFoundException(String message) {
        super(message);
    }
}
