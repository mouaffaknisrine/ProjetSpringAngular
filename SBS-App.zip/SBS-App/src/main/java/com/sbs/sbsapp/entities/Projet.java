package com.sbs.sbsapp.entities;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.sbs.sbsapp.enums.Practice;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Generated;
import lombok.NoArgsConstructor;
import jakarta.persistence.OneToMany;

import java.util.Collection;
import java.util.List;

@Data @AllArgsConstructor @NoArgsConstructor
@Entity
public class Projet {
    @Id
    private String  id;
    @Column(length = 30)
    private String nom;
    @Column(length = 30)
    private String typeActivite;
    private int agence;
    @Column(length = 30)
    private String chefProjet;
    @Enumerated(EnumType.STRING)
    private Practice practice;
    @OneToMany(mappedBy = "projet")
    //pour n a pas a chaque fois afficher la liste de collab
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private List<Collaborateur> collaborateurs;

}
