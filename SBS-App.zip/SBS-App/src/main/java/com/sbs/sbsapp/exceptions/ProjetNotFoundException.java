package com.sbs.sbsapp.exceptions;

public class ProjetNotFoundException extends Exception {
    public ProjetNotFoundException(String message) {
        super(message);
    }
}
