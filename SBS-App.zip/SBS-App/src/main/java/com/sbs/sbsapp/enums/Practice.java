package com.sbs.sbsapp.enums;

public enum Practice {
    PS_DEV_DIGI("Ps-dev"), R_EDITIQUE("R-Editique");

    private final String value;

    private Practice(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
