package com.sbs.sbsapp.dtos;

import com.sbs.sbsapp.enums.Practice;
import lombok.Data;

@Data
public class ProjetDTO {
    private String  id;
    private String nom;
    private String typeActivite;
    private int agence;
    private String chefProjet;
    private Practice practice;
}
