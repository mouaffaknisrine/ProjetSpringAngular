package com.sbs.sbsapp.web;

import com.sbs.sbsapp.dtos.ProjetDTO;
import com.sbs.sbsapp.exceptions.ProjetNotFoundException;
import com.sbs.sbsapp.services.AppService;
import jakarta.websocket.server.PathParam;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@AllArgsConstructor
@Slf4j
public class ProjetRestController {
    private AppService appService;
    @GetMapping("/projets")
    public List<ProjetDTO> projets(){
        return appService.listProjets();
    }
    @GetMapping("/projets/{id}")
    public ProjetDTO getProjet(@PathVariable(name = "id") String projetId) throws ProjetNotFoundException {
        return appService.getProjet(projetId);
    }
    @PostMapping("/projets")
    public ProjetDTO saveProjet (@RequestBody ProjetDTO projetDTO){
        return appService.saveProjet(projetDTO);
    }
    @PutMapping("/projets/{projetId}")
    public ProjetDTO ypdateProjet(@PathVariable String projetId,@RequestBody ProjetDTO projetDTO){
        projetDTO.setId(projetId);
        return appService.updateProjet(projetDTO);
    }
    @DeleteMapping("/projets/{id}")
    public void deleteProjet(@PathVariable String id){
        appService.deleteProjet(id);
    }
}
