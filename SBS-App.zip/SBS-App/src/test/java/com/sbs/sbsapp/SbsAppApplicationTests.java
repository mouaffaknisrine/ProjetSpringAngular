package com.sbs.sbsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbsAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
